Thank you for using Help->Help, the way to make help files and be able to focus on the creative process. This is the first release, version 1.00 and is for Windows 95/NT.


Please direct comments, suggestions and bug reports to:

	e-mail	HelpHelp@ayecor.com

	- or -

	visit the AyeCor Software web site at:  http://ayecor.com


Registering Help->Help:

Why register?  

First, is the program useful?  Does it perform a task that you find valuable?  Of course you'll get that good feeling that comes with "doing the right thing".


Pricing.
Whether you purchase through the mail, via check or money order and have the program mailed back, or register online with a credit card or by other means, the price will be the same; $24.95.  Initially we tried to charge a base price and add charges for shipping and disks, or online registration fees.  Finally (a) it became too complicated and (b) one couldn't actually purchase the program for the base price anyway unless they came here and picked it up personally.


You can register online by going to the AyeCor site at:
http://ayecor.com

-OR-

Send a check or money order to:
AyeCor Software
2115 Pillsbury Ave. S.
Minneapolis, MN  55404

The check or money order must be in US dollars and drawn on a US bank.