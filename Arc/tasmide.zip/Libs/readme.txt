Put all your libraries in here for easy use in the IDE. 
Ignore this file, it's just to create the directory in WinZip.